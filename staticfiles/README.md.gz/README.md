Static assets for the project.

Folders:
- images/  -> store project images (logos, icons, uploads prep)
- css/     -> store stylesheets
- js/      -> store JavaScript files

Notes:
- In production you may serve static files via WhiteNoise or a CDN.
- Keep this folder committed unless you have a separate build pipeline that generates static assets.
